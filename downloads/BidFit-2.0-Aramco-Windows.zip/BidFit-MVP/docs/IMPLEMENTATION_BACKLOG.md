# BidFit 2.0 implementation stages

1. Inventory/baseline: existing React/Vite UI, FastAPI/Pydantic API, SQLAlchemy JSON domain store on PostgreSQL, Alembic, private S3 adapter/disk emulator, separate leased worker, cookie/CSRF demo auth + configured OIDC adapter. Existing extraction is explicitly pattern based, not genuine AI; paid provider adapter is unverified. Preserve original endpoints/data and Windows demo branch.
2. Package A: central product/market/application/customer master data; classification wizard and editable saved classification; per-tag equipment categories; persistent RFQ context; richer manifest/revisions/multiple uploads; DOCX/XLSX/ZIP parsing with bounded safe archives; concise source-backed summary and an explicit reviewed-summary gate before PROCESS RFQ. Legacy RFQs remain accessible.
3. Package B: standard metadata registry and three separate layers (suggestion, RFQ requirement, approved rule); versioned synthetic-only rule registry, designated engineering approval, detailed compliance findings, unknown/conflict/coverage gates, immutable evaluation/report hashes and stale-review detection. No copyrighted clauses or real capability limits are invented.
4. Package C: product-family library, read-only extracted inputs, manually referenced candidates, evidence/status/reviewer records, adapter contract. No fabricated selection or curves.
5. Package D foundation: manual sourced pricing references, ICAP status, versioned draft quotation output with missing information explicit; no invented price calculations or commitments.
6. Branding, regression/security/end-to-end checks, compatibility, docs, updated downloadable Windows package and separate GitHub branch. Preserve old Windows ZIP and startup/data volumes. Real branding image byte files are not exposed by this chat: exact-asset upload/configuration is needed, not logo generation.

Existing-working baseline to revalidate: projects, upload/worker, cited facts/corrections, four synthetic outcomes, tenant/project authorization, optimistic concurrency, CSRF, frozen exports, Windows Docker images. Existing-needs-improvement: navigation/metadata, format coverage, review gating, standards. Missing: classification/registries/studios. Blocked-by-data: real standards/capabilities, OIDC/provider validation, pricing/curves. Future: certified selection, production release and full corporate integrations.

## Delivered package status

- **A — working and tested:** central taxonomy/configuration, wizard, category-specific tag register, saved customer/project fields, additional/revised/multiple/drop uploads, bounded DOCX/XLSX/ZIP, exact source review, editable summary and explicit PROCESS RFQ gate. Complex Office layouts, scanned OCR and folder selection are not claimed supported. Full arbitrary-document extraction quality awaits approved provider validation.
- **B — working synthetic foundation and tested:** metadata standards registry; distinct suggestion/explicit/approved layers; immutable versioned synthetic-rule publication with permission, finite units/basis checks, detailed findings, four decisions, mixed-package rollup, stale approvals, conservative adjudication and frozen exports. Real standards/clauses/portfolio rules remain blocked by approved data. No unsupported real compliance success is reported.
- **C — working foundation and tested:** family metadata, RFQ input reuse, manual candidates, source references, input-staleness checks and reference-review history. Approved performance/capability engine is pending data and engineering validation.
- **D — working limited foundation and tested:** sourced draft price references and immutable draft technical quotation exports. No actual cost integration, official GOAL weights, approved selling prices, terms or submission approval.
- **Branding — partial:** centralized provisional blue/grey tokens and exact-original PNG upload displayed on login/navigation. Original inline image bytes could not be accessed as files; exact prebundled logo/secondary marks remain outstanding. No logo was recreated or substituted.

Next recommended work: supply/configure the original KSB logo file; have engineering define the minimum real screening coverage and authorize source/rule/capability data; then validate one product family's rules and references before activating live engineering or product selection. Corporate identity configuration, full role/membership administration, malware scanning, retention/RLS and production operations remain release gates. Native Windows verification is still required. No public deployment or purchase was performed.


## Aramco Approval Intelligence upgrade

Implemented: relational historical registry, eight portfolio associations, source
provenance, item-level deterministic checks, administration, candidate review,
policy versions, history/staleness, frozen reports and synthetic examples.

Pending: original PDF/PPTX inspection, controlled real document ingestion,
authoritative current source validation, configuration/component approvals and
live exclusion rules. Metadata or synthetic verification never closes these gaps.
